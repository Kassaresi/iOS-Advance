//
//  ProfileApp.swift
//  Profile
//
//  Created by Alikhan Kassiman on 2025.02.06.
//

import SwiftUI

@main
struct ProfileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

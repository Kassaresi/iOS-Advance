//
//  FootballComandLinkView.swift
//  Profile
//
//  Created by Alikhan Kassiman on 2025.02.07.
//

import SwiftUI

struct FootballComandLinkView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    FootballComandLinkView()
}
